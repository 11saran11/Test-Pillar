﻿using Microsoft.EntityFrameworkCore;
using Pillar.Core;

namespace Pillar.Logging
{
    public class LoggingContext : DbContext
    {
        public readonly string _connectionString = string.Empty;
        public DbSet<Log> Log { get; set; }
        public DbSet<LogTypeMap> Logtype { get; set; }
        public DbSet<ApplicationMap> Application { get; set; }
        public DbSet<SystemsMap> Systems { get; set; }
        public DbSet<PillarTypeMap> Pillartype { get; set; }
        public LoggingContext()
        {
            PillarConfiguration Configuration = new(CoreProvider.GetEnvironment());
            _connectionString = Configuration.ConnectionString;
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(_connectionString);
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<LogTypeMap>().HasData(PillarConfiguration.EnumNamedValues<LogType, LogTypeMap>());
            modelBuilder.Entity<PillarTypeMap>().HasData(PillarConfiguration.EnumNamedValues<PillarType, PillarTypeMap>());
            modelBuilder.Entity<ApplicationMap>().HasData(PillarConfiguration.EnumNamedValues<Application, ApplicationMap>());
            modelBuilder.Entity<SystemsMap>().HasData(PillarConfiguration.EnumNamedValues<Systems, SystemsMap>());
            base.OnModelCreating(modelBuilder);
        }
    }
}
