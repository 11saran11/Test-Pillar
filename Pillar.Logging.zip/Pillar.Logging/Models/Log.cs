﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Pillar.Logging
{
    [Table("Log", Schema = "Pillar.Logging")]
    [Index(nameof(DateCreated), nameof(ApplicationId), nameof(PillarId), Name = "DateCreated_AppId_PillarId")]
    [Index(nameof(DateCreated), nameof(ApplicationId), nameof(PillarId), Name = "DateCreated_SiteId_UserId")]
    public class Log
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long LogId { get; set; }
        [Required]
        public int LogType { get; set; }
        [Required]
        public int PillarId { get; set; }
        [Required]
        public int SystemId { get; set; }
        [Required]
        public int ApplicationId { get; set; }
        [Required]
        public long SiteId { get; set; }
        [Required]
        public long? UserId { get; set; }
        [Required, StringLength(256)]
        public string Description { get; set; }
        public string? Message { get; set; }
        public string? StackTrace { get; set; }
        [Required]
        public DateTime DateCreated { get; set; } = DateTime.UtcNow;

        [ForeignKey("LogType")]
        public LogTypeMap LogTypeMap { get; set; }
        [ForeignKey("PillarId")]
        public PillarTypeMap PillarTypeMap { get; set; }
        [ForeignKey("SystemId")]
        public SystemsMap SystemsMap { get; set; }
        [ForeignKey("ApplicationId")]
        public ApplicationMap ApplicationMap { get; set; }
    }
}
