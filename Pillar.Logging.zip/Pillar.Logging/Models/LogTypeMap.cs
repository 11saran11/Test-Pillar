﻿using Pillar.Core;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pillar.Logging
{
    [Table("LogTypeMap", Schema = "Pillar.Logging")]
    public class LogTypeMap : IEnum
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        [Required, StringLength(128)]
        public string Name { get; set; }
        [StringLength(256)]
        public string? Description { get; set; }
        [Required]
        public DateTime DateCreated { get; set; } = DateTime.UtcNow;
        public virtual ICollection<Log> Logs { get; set; }
    }
}
