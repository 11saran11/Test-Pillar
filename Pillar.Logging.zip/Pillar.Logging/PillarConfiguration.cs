﻿
using Pillar.Core;

namespace Pillar.Logging
{
    internal class PillarConfiguration
    {
        public readonly string _connectionString = string.Empty;
        public PillarConfiguration(Env env)
        {
            switch (env)
            {
                case Env.Development:
                    _connectionString = @"Server=52.19.65.217;Database=T3;User Id=Pillar.Logging;Password=702E0^V&wqA0KX6lXBpmTiszZO*9jEtyYe&Y;";
                    break;
                case Env.Staging:
                    _connectionString = @"Server=(local);Database=TesselloV3-Dev;User Id=kojakAWS;Password=myboylollipop;Trusted_Connection=True;";
                    break;
                case Env.Production:
                    _connectionString = @"Server=(local);Database=TesselloV3-Dev;User Id=kojakAWS;Password=myboylollipop;Trusted_Connection=True;";
                    break;
                default:
                    _connectionString = @"Server=(local);Database=TesselloV3-Dev;User Id=kojakAWS;Password=myboylollipop;Trusted_Connection=True;";
                    break;
            };
        }
        /// <summary>
        /// Get the connection string for database connectivity
        /// </summary>
        public string ConnectionString
        {
            get => _connectionString;
        }
        /// <summary>
        /// Get List of enum values to instantiate the enums into the database.
        /// </summary>
        /// <typeparam name="TOne">System.Enum type</typeparam>
        /// <typeparam name="TTwo">enum table Model</typeparam>
        /// <returns>List of enum values</returns>
        public static List<TTwo> EnumNamedValues<TOne, TTwo>() where TTwo : IEnum, new()
        {
            List<TTwo> result = new List<TTwo>();
            foreach (int item in Enum.GetValues(typeof(TOne)))
            {
                TTwo enumType = new TTwo();
                enumType.Id = item;
                enumType.Name = Enum.GetName(typeof(TOne), item);
                enumType.Description = "";
                result.Add(enumType);
            }
            return result;
        }
    }
}
