﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Pillar.Logging.Migrations
{
    public partial class CreateLogginPillar : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "ApplicationMap",
                keyColumn: "Id",
                keyValue: 1,
                column: "DateCreated",
                value: new DateTime(2022, 10, 18, 12, 40, 48, 718, DateTimeKind.Utc).AddTicks(5989));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "ApplicationMap",
                keyColumn: "Id",
                keyValue: 2,
                column: "DateCreated",
                value: new DateTime(2022, 10, 18, 12, 40, 48, 718, DateTimeKind.Utc).AddTicks(6023));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "Id",
                keyValue: 1,
                column: "DateCreated",
                value: new DateTime(2022, 10, 18, 12, 40, 48, 718, DateTimeKind.Utc).AddTicks(4561));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "Id",
                keyValue: 2,
                column: "DateCreated",
                value: new DateTime(2022, 10, 18, 12, 40, 48, 718, DateTimeKind.Utc).AddTicks(4673));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "Id",
                keyValue: 3,
                column: "DateCreated",
                value: new DateTime(2022, 10, 18, 12, 40, 48, 718, DateTimeKind.Utc).AddTicks(4680));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "Id",
                keyValue: 4,
                column: "DateCreated",
                value: new DateTime(2022, 10, 18, 12, 40, 48, 718, DateTimeKind.Utc).AddTicks(4685));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "Id",
                keyValue: 5,
                column: "DateCreated",
                value: new DateTime(2022, 10, 18, 12, 40, 48, 718, DateTimeKind.Utc).AddTicks(4691));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "Id",
                keyValue: 6,
                column: "DateCreated",
                value: new DateTime(2022, 10, 18, 12, 40, 48, 718, DateTimeKind.Utc).AddTicks(4702));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "PillarTypeMap",
                keyColumn: "Id",
                keyValue: 1,
                column: "DateCreated",
                value: new DateTime(2022, 10, 18, 12, 40, 48, 718, DateTimeKind.Utc).AddTicks(4838));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "PillarTypeMap",
                keyColumn: "Id",
                keyValue: 2,
                column: "DateCreated",
                value: new DateTime(2022, 10, 18, 12, 40, 48, 718, DateTimeKind.Utc).AddTicks(4867));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "PillarTypeMap",
                keyColumn: "Id",
                keyValue: 3,
                column: "DateCreated",
                value: new DateTime(2022, 10, 18, 12, 40, 48, 718, DateTimeKind.Utc).AddTicks(4873));

            migrationBuilder.InsertData(
                schema: "Pillar.Logging",
                table: "PillarTypeMap",
                columns: new[] { "Id", "DateCreated", "Description", "Name" },
                values: new object[,]
                {
                    { 4, new DateTime(2022, 10, 18, 12, 40, 48, 718, DateTimeKind.Utc).AddTicks(5812), "", "Mapping" },
                    { 5, new DateTime(2022, 10, 18, 12, 40, 48, 718, DateTimeKind.Utc).AddTicks(5823), "", "Text" }
                });

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "SystemsMap",
                keyColumn: "Id",
                keyValue: 1,
                column: "DateCreated",
                value: new DateTime(2022, 10, 18, 12, 40, 48, 718, DateTimeKind.Utc).AddTicks(6106));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "SystemsMap",
                keyColumn: "Id",
                keyValue: 2,
                column: "DateCreated",
                value: new DateTime(2022, 10, 18, 12, 40, 48, 718, DateTimeKind.Utc).AddTicks(6140));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "SystemsMap",
                keyColumn: "Id",
                keyValue: 3,
                column: "DateCreated",
                value: new DateTime(2022, 10, 18, 12, 40, 48, 718, DateTimeKind.Utc).AddTicks(6148));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "SystemsMap",
                keyColumn: "Id",
                keyValue: 4,
                column: "DateCreated",
                value: new DateTime(2022, 10, 18, 12, 40, 48, 718, DateTimeKind.Utc).AddTicks(6154));
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                schema: "Pillar.Logging",
                table: "PillarTypeMap",
                keyColumn: "Id",
                keyValue: 4);

            migrationBuilder.DeleteData(
                schema: "Pillar.Logging",
                table: "PillarTypeMap",
                keyColumn: "Id",
                keyValue: 5);

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "ApplicationMap",
                keyColumn: "Id",
                keyValue: 1,
                column: "DateCreated",
                value: new DateTime(2022, 9, 15, 5, 12, 31, 900, DateTimeKind.Utc).AddTicks(7968));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "ApplicationMap",
                keyColumn: "Id",
                keyValue: 2,
                column: "DateCreated",
                value: new DateTime(2022, 9, 15, 5, 12, 31, 900, DateTimeKind.Utc).AddTicks(7979));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "Id",
                keyValue: 1,
                column: "DateCreated",
                value: new DateTime(2022, 9, 15, 5, 12, 31, 900, DateTimeKind.Utc).AddTicks(7820));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "Id",
                keyValue: 2,
                column: "DateCreated",
                value: new DateTime(2022, 9, 15, 5, 12, 31, 900, DateTimeKind.Utc).AddTicks(7857));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "Id",
                keyValue: 3,
                column: "DateCreated",
                value: new DateTime(2022, 9, 15, 5, 12, 31, 900, DateTimeKind.Utc).AddTicks(7861));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "Id",
                keyValue: 4,
                column: "DateCreated",
                value: new DateTime(2022, 9, 15, 5, 12, 31, 900, DateTimeKind.Utc).AddTicks(7864));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "Id",
                keyValue: 5,
                column: "DateCreated",
                value: new DateTime(2022, 9, 15, 5, 12, 31, 900, DateTimeKind.Utc).AddTicks(7866));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "Id",
                keyValue: 6,
                column: "DateCreated",
                value: new DateTime(2022, 9, 15, 5, 12, 31, 900, DateTimeKind.Utc).AddTicks(7870));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "PillarTypeMap",
                keyColumn: "Id",
                keyValue: 1,
                column: "DateCreated",
                value: new DateTime(2022, 9, 15, 5, 12, 31, 900, DateTimeKind.Utc).AddTicks(7911));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "PillarTypeMap",
                keyColumn: "Id",
                keyValue: 2,
                column: "DateCreated",
                value: new DateTime(2022, 9, 15, 5, 12, 31, 900, DateTimeKind.Utc).AddTicks(7925));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "PillarTypeMap",
                keyColumn: "Id",
                keyValue: 3,
                column: "DateCreated",
                value: new DateTime(2022, 9, 15, 5, 12, 31, 900, DateTimeKind.Utc).AddTicks(7928));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "SystemsMap",
                keyColumn: "Id",
                keyValue: 1,
                column: "DateCreated",
                value: new DateTime(2022, 9, 15, 5, 12, 31, 900, DateTimeKind.Utc).AddTicks(8013));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "SystemsMap",
                keyColumn: "Id",
                keyValue: 2,
                column: "DateCreated",
                value: new DateTime(2022, 9, 15, 5, 12, 31, 900, DateTimeKind.Utc).AddTicks(8025));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "SystemsMap",
                keyColumn: "Id",
                keyValue: 3,
                column: "DateCreated",
                value: new DateTime(2022, 9, 15, 5, 12, 31, 900, DateTimeKind.Utc).AddTicks(8028));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "SystemsMap",
                keyColumn: "Id",
                keyValue: 4,
                column: "DateCreated",
                value: new DateTime(2022, 9, 15, 5, 12, 31, 900, DateTimeKind.Utc).AddTicks(8030));
        }
    }
}
