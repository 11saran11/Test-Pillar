﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Pillar.Logging.Migrations
{
    public partial class UpdateLoggingPillar : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                schema: "Pillar.Logging",
                table: "PillarTypeMap",
                keyColumn: "Id",
                keyValue: 5);

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "ApplicationMap",
                keyColumn: "Id",
                keyValue: 1,
                column: "DateCreated",
                value: new DateTime(2022, 10, 26, 7, 41, 38, 396, DateTimeKind.Utc).AddTicks(1814));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "ApplicationMap",
                keyColumn: "Id",
                keyValue: 2,
                column: "DateCreated",
                value: new DateTime(2022, 10, 26, 7, 41, 38, 396, DateTimeKind.Utc).AddTicks(1823));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "Id",
                keyValue: 1,
                column: "DateCreated",
                value: new DateTime(2022, 10, 26, 7, 41, 38, 396, DateTimeKind.Utc).AddTicks(1660));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "Id",
                keyValue: 2,
                column: "DateCreated",
                value: new DateTime(2022, 10, 26, 7, 41, 38, 396, DateTimeKind.Utc).AddTicks(1703));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "Id",
                keyValue: 3,
                column: "DateCreated",
                value: new DateTime(2022, 10, 26, 7, 41, 38, 396, DateTimeKind.Utc).AddTicks(1706));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "Id",
                keyValue: 4,
                column: "DateCreated",
                value: new DateTime(2022, 10, 26, 7, 41, 38, 396, DateTimeKind.Utc).AddTicks(1708));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "Id",
                keyValue: 5,
                column: "DateCreated",
                value: new DateTime(2022, 10, 26, 7, 41, 38, 396, DateTimeKind.Utc).AddTicks(1711));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "Id",
                keyValue: 6,
                column: "DateCreated",
                value: new DateTime(2022, 10, 26, 7, 41, 38, 396, DateTimeKind.Utc).AddTicks(1715));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "PillarTypeMap",
                keyColumn: "Id",
                keyValue: 1,
                column: "DateCreated",
                value: new DateTime(2022, 10, 26, 7, 41, 38, 396, DateTimeKind.Utc).AddTicks(1763));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "PillarTypeMap",
                keyColumn: "Id",
                keyValue: 2,
                column: "DateCreated",
                value: new DateTime(2022, 10, 26, 7, 41, 38, 396, DateTimeKind.Utc).AddTicks(1776));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "PillarTypeMap",
                keyColumn: "Id",
                keyValue: 3,
                columns: new[] { "DateCreated", "Name" },
                values: new object[] { new DateTime(2022, 10, 26, 7, 41, 38, 396, DateTimeKind.Utc).AddTicks(1779), "Mapping" });

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "PillarTypeMap",
                keyColumn: "Id",
                keyValue: 4,
                columns: new[] { "DateCreated", "Name" },
                values: new object[] { new DateTime(2022, 10, 26, 7, 41, 38, 396, DateTimeKind.Utc).AddTicks(1781), "Text" });

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "SystemsMap",
                keyColumn: "Id",
                keyValue: 1,
                column: "DateCreated",
                value: new DateTime(2022, 10, 26, 7, 41, 38, 396, DateTimeKind.Utc).AddTicks(1859));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "SystemsMap",
                keyColumn: "Id",
                keyValue: 2,
                column: "DateCreated",
                value: new DateTime(2022, 10, 26, 7, 41, 38, 396, DateTimeKind.Utc).AddTicks(1871));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "SystemsMap",
                keyColumn: "Id",
                keyValue: 3,
                column: "DateCreated",
                value: new DateTime(2022, 10, 26, 7, 41, 38, 396, DateTimeKind.Utc).AddTicks(1874));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "SystemsMap",
                keyColumn: "Id",
                keyValue: 4,
                column: "DateCreated",
                value: new DateTime(2022, 10, 26, 7, 41, 38, 396, DateTimeKind.Utc).AddTicks(1876));
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "ApplicationMap",
                keyColumn: "Id",
                keyValue: 1,
                column: "DateCreated",
                value: new DateTime(2022, 10, 18, 12, 40, 48, 718, DateTimeKind.Utc).AddTicks(5989));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "ApplicationMap",
                keyColumn: "Id",
                keyValue: 2,
                column: "DateCreated",
                value: new DateTime(2022, 10, 18, 12, 40, 48, 718, DateTimeKind.Utc).AddTicks(6023));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "Id",
                keyValue: 1,
                column: "DateCreated",
                value: new DateTime(2022, 10, 18, 12, 40, 48, 718, DateTimeKind.Utc).AddTicks(4561));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "Id",
                keyValue: 2,
                column: "DateCreated",
                value: new DateTime(2022, 10, 18, 12, 40, 48, 718, DateTimeKind.Utc).AddTicks(4673));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "Id",
                keyValue: 3,
                column: "DateCreated",
                value: new DateTime(2022, 10, 18, 12, 40, 48, 718, DateTimeKind.Utc).AddTicks(4680));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "Id",
                keyValue: 4,
                column: "DateCreated",
                value: new DateTime(2022, 10, 18, 12, 40, 48, 718, DateTimeKind.Utc).AddTicks(4685));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "Id",
                keyValue: 5,
                column: "DateCreated",
                value: new DateTime(2022, 10, 18, 12, 40, 48, 718, DateTimeKind.Utc).AddTicks(4691));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "Id",
                keyValue: 6,
                column: "DateCreated",
                value: new DateTime(2022, 10, 18, 12, 40, 48, 718, DateTimeKind.Utc).AddTicks(4702));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "PillarTypeMap",
                keyColumn: "Id",
                keyValue: 1,
                column: "DateCreated",
                value: new DateTime(2022, 10, 18, 12, 40, 48, 718, DateTimeKind.Utc).AddTicks(4838));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "PillarTypeMap",
                keyColumn: "Id",
                keyValue: 2,
                column: "DateCreated",
                value: new DateTime(2022, 10, 18, 12, 40, 48, 718, DateTimeKind.Utc).AddTicks(4867));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "PillarTypeMap",
                keyColumn: "Id",
                keyValue: 3,
                columns: new[] { "DateCreated", "Name" },
                values: new object[] { new DateTime(2022, 10, 18, 12, 40, 48, 718, DateTimeKind.Utc).AddTicks(4873), "Tests" });

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "PillarTypeMap",
                keyColumn: "Id",
                keyValue: 4,
                columns: new[] { "DateCreated", "Name" },
                values: new object[] { new DateTime(2022, 10, 18, 12, 40, 48, 718, DateTimeKind.Utc).AddTicks(5812), "Mapping" });

            migrationBuilder.InsertData(
                schema: "Pillar.Logging",
                table: "PillarTypeMap",
                columns: new[] { "Id", "DateCreated", "Description", "Name" },
                values: new object[] { 5, new DateTime(2022, 10, 18, 12, 40, 48, 718, DateTimeKind.Utc).AddTicks(5823), "", "Text" });

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "SystemsMap",
                keyColumn: "Id",
                keyValue: 1,
                column: "DateCreated",
                value: new DateTime(2022, 10, 18, 12, 40, 48, 718, DateTimeKind.Utc).AddTicks(6106));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "SystemsMap",
                keyColumn: "Id",
                keyValue: 2,
                column: "DateCreated",
                value: new DateTime(2022, 10, 18, 12, 40, 48, 718, DateTimeKind.Utc).AddTicks(6140));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "SystemsMap",
                keyColumn: "Id",
                keyValue: 3,
                column: "DateCreated",
                value: new DateTime(2022, 10, 18, 12, 40, 48, 718, DateTimeKind.Utc).AddTicks(6148));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "SystemsMap",
                keyColumn: "Id",
                keyValue: 4,
                column: "DateCreated",
                value: new DateTime(2022, 10, 18, 12, 40, 48, 718, DateTimeKind.Utc).AddTicks(6154));
        }
    }
}
