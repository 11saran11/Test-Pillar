﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Pillar.Logging.Migrations
{
    public partial class LogTypeMapUpdate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "LogtypeId",
                keyValue: 1,
                column: "DateCreated",
                value: new DateTime(2022, 9, 14, 10, 21, 45, 785, DateTimeKind.Utc).AddTicks(9677));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "LogtypeId",
                keyValue: 2,
                column: "DateCreated",
                value: new DateTime(2022, 9, 14, 10, 21, 45, 785, DateTimeKind.Utc).AddTicks(9688));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "LogtypeId",
                keyValue: 3,
                column: "DateCreated",
                value: new DateTime(2022, 9, 14, 10, 21, 45, 785, DateTimeKind.Utc).AddTicks(9744));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "LogtypeId",
                keyValue: 4,
                column: "DateCreated",
                value: new DateTime(2022, 9, 14, 10, 21, 45, 785, DateTimeKind.Utc).AddTicks(9747));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "LogtypeId",
                keyValue: 5,
                column: "DateCreated",
                value: new DateTime(2022, 9, 14, 10, 21, 45, 785, DateTimeKind.Utc).AddTicks(9750));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "LogtypeId",
                keyValue: 6,
                column: "DateCreated",
                value: new DateTime(2022, 9, 14, 10, 21, 45, 785, DateTimeKind.Utc).AddTicks(9758));
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "LogtypeId",
                keyValue: 1,
                column: "DateCreated",
                value: new DateTime(2022, 9, 14, 6, 39, 0, 140, DateTimeKind.Utc).AddTicks(4953));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "LogtypeId",
                keyValue: 2,
                column: "DateCreated",
                value: new DateTime(2022, 9, 14, 6, 39, 0, 140, DateTimeKind.Utc).AddTicks(4961));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "LogtypeId",
                keyValue: 3,
                column: "DateCreated",
                value: new DateTime(2022, 9, 14, 6, 39, 0, 140, DateTimeKind.Utc).AddTicks(4965));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "LogtypeId",
                keyValue: 4,
                column: "DateCreated",
                value: new DateTime(2022, 9, 14, 6, 39, 0, 140, DateTimeKind.Utc).AddTicks(4968));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "LogtypeId",
                keyValue: 5,
                column: "DateCreated",
                value: new DateTime(2022, 9, 14, 6, 39, 0, 140, DateTimeKind.Utc).AddTicks(4972));

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "LogtypeId",
                keyValue: 6,
                column: "DateCreated",
                value: new DateTime(2022, 9, 14, 6, 39, 0, 140, DateTimeKind.Utc).AddTicks(4977));
        }
    }
}
