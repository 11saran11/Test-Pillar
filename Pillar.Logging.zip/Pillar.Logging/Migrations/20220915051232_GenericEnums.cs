﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Pillar.Logging.Migrations
{
    public partial class GenericEnums : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "LogtypeId",
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                newName: "Id");

            migrationBuilder.CreateTable(
                name: "ApplicationMap",
                schema: "Pillar.Logging",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(128)", maxLength: 128, nullable: false),
                    Description = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    DateCreated = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ApplicationMap", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "PillarTypeMap",
                schema: "Pillar.Logging",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(128)", maxLength: 128, nullable: false),
                    Description = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    DateCreated = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PillarTypeMap", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "SystemsMap",
                schema: "Pillar.Logging",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(128)", maxLength: 128, nullable: false),
                    Description = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    DateCreated = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SystemsMap", x => x.Id);
                });

            migrationBuilder.InsertData(
                schema: "Pillar.Logging",
                table: "ApplicationMap",
                columns: new[] { "Id", "DateCreated", "Description", "Name" },
                values: new object[,]
                {
                    { 1, new DateTime(2022, 9, 15, 5, 12, 31, 900, DateTimeKind.Utc).AddTicks(7968), "", "TesselloV2" },
                    { 2, new DateTime(2022, 9, 15, 5, 12, 31, 900, DateTimeKind.Utc).AddTicks(7979), "", "TesselloV3" }
                });

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "DateCreated", "Description" },
                values: new object[] { new DateTime(2022, 9, 15, 5, 12, 31, 900, DateTimeKind.Utc).AddTicks(7820), "" });

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "Id",
                keyValue: 2,
                columns: new[] { "DateCreated", "Description" },
                values: new object[] { new DateTime(2022, 9, 15, 5, 12, 31, 900, DateTimeKind.Utc).AddTicks(7857), "" });

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "Id",
                keyValue: 3,
                columns: new[] { "DateCreated", "Description" },
                values: new object[] { new DateTime(2022, 9, 15, 5, 12, 31, 900, DateTimeKind.Utc).AddTicks(7861), "" });

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "Id",
                keyValue: 4,
                columns: new[] { "DateCreated", "Description" },
                values: new object[] { new DateTime(2022, 9, 15, 5, 12, 31, 900, DateTimeKind.Utc).AddTicks(7864), "" });

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "Id",
                keyValue: 5,
                columns: new[] { "DateCreated", "Description" },
                values: new object[] { new DateTime(2022, 9, 15, 5, 12, 31, 900, DateTimeKind.Utc).AddTicks(7866), "" });

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "Id",
                keyValue: 6,
                columns: new[] { "DateCreated", "Description" },
                values: new object[] { new DateTime(2022, 9, 15, 5, 12, 31, 900, DateTimeKind.Utc).AddTicks(7870), "" });

            migrationBuilder.InsertData(
                schema: "Pillar.Logging",
                table: "PillarTypeMap",
                columns: new[] { "Id", "DateCreated", "Description", "Name" },
                values: new object[,]
                {
                    { 1, new DateTime(2022, 9, 15, 5, 12, 31, 900, DateTimeKind.Utc).AddTicks(7911), "", "Core" },
                    { 2, new DateTime(2022, 9, 15, 5, 12, 31, 900, DateTimeKind.Utc).AddTicks(7925), "", "Logging" },
                    { 3, new DateTime(2022, 9, 15, 5, 12, 31, 900, DateTimeKind.Utc).AddTicks(7928), "", "Tests" }
                });

            migrationBuilder.InsertData(
                schema: "Pillar.Logging",
                table: "SystemsMap",
                columns: new[] { "Id", "DateCreated", "Description", "Name" },
                values: new object[,]
                {
                    { 1, new DateTime(2022, 9, 15, 5, 12, 31, 900, DateTimeKind.Utc).AddTicks(8013), "", "DevReview" },
                    { 2, new DateTime(2022, 9, 15, 5, 12, 31, 900, DateTimeKind.Utc).AddTicks(8025), "", "DevCR" },
                    { 3, new DateTime(2022, 9, 15, 5, 12, 31, 900, DateTimeKind.Utc).AddTicks(8028), "", "Staging" },
                    { 4, new DateTime(2022, 9, 15, 5, 12, 31, 900, DateTimeKind.Utc).AddTicks(8030), "", "Live" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Log_ApplicationId",
                schema: "Pillar.Logging",
                table: "Log",
                column: "ApplicationId");

            migrationBuilder.CreateIndex(
                name: "IX_Log_PillarId",
                schema: "Pillar.Logging",
                table: "Log",
                column: "PillarId");

            migrationBuilder.CreateIndex(
                name: "IX_Log_SystemId",
                schema: "Pillar.Logging",
                table: "Log",
                column: "SystemId");

            migrationBuilder.AddForeignKey(
                name: "FK_Log_ApplicationMap_ApplicationId",
                schema: "Pillar.Logging",
                table: "Log",
                column: "ApplicationId",
                principalSchema: "Pillar.Logging",
                principalTable: "ApplicationMap",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Log_PillarTypeMap_PillarId",
                schema: "Pillar.Logging",
                table: "Log",
                column: "PillarId",
                principalSchema: "Pillar.Logging",
                principalTable: "PillarTypeMap",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Log_SystemsMap_SystemId",
                schema: "Pillar.Logging",
                table: "Log",
                column: "SystemId",
                principalSchema: "Pillar.Logging",
                principalTable: "SystemsMap",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Log_ApplicationMap_ApplicationId",
                schema: "Pillar.Logging",
                table: "Log");

            migrationBuilder.DropForeignKey(
                name: "FK_Log_PillarTypeMap_PillarId",
                schema: "Pillar.Logging",
                table: "Log");

            migrationBuilder.DropForeignKey(
                name: "FK_Log_SystemsMap_SystemId",
                schema: "Pillar.Logging",
                table: "Log");

            migrationBuilder.DropTable(
                name: "ApplicationMap",
                schema: "Pillar.Logging");

            migrationBuilder.DropTable(
                name: "PillarTypeMap",
                schema: "Pillar.Logging");

            migrationBuilder.DropTable(
                name: "SystemsMap",
                schema: "Pillar.Logging");

            migrationBuilder.DropIndex(
                name: "IX_Log_ApplicationId",
                schema: "Pillar.Logging",
                table: "Log");

            migrationBuilder.DropIndex(
                name: "IX_Log_PillarId",
                schema: "Pillar.Logging",
                table: "Log");

            migrationBuilder.DropIndex(
                name: "IX_Log_SystemId",
                schema: "Pillar.Logging",
                table: "Log");

            migrationBuilder.RenameColumn(
                name: "Id",
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                newName: "LogtypeId");

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "LogtypeId",
                keyValue: 1,
                columns: new[] { "DateCreated", "Description" },
                values: new object[] { new DateTime(2022, 9, 14, 10, 21, 45, 785, DateTimeKind.Utc).AddTicks(9677), null });

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "LogtypeId",
                keyValue: 2,
                columns: new[] { "DateCreated", "Description" },
                values: new object[] { new DateTime(2022, 9, 14, 10, 21, 45, 785, DateTimeKind.Utc).AddTicks(9688), null });

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "LogtypeId",
                keyValue: 3,
                columns: new[] { "DateCreated", "Description" },
                values: new object[] { new DateTime(2022, 9, 14, 10, 21, 45, 785, DateTimeKind.Utc).AddTicks(9744), null });

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "LogtypeId",
                keyValue: 4,
                columns: new[] { "DateCreated", "Description" },
                values: new object[] { new DateTime(2022, 9, 14, 10, 21, 45, 785, DateTimeKind.Utc).AddTicks(9747), null });

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "LogtypeId",
                keyValue: 5,
                columns: new[] { "DateCreated", "Description" },
                values: new object[] { new DateTime(2022, 9, 14, 10, 21, 45, 785, DateTimeKind.Utc).AddTicks(9750), null });

            migrationBuilder.UpdateData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                keyColumn: "LogtypeId",
                keyValue: 6,
                columns: new[] { "DateCreated", "Description" },
                values: new object[] { new DateTime(2022, 9, 14, 10, 21, 45, 785, DateTimeKind.Utc).AddTicks(9758), null });
        }
    }
}
