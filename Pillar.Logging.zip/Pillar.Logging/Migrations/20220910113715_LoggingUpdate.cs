﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Pillar.Logging.Migrations
{
    public partial class LoggingUpdate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "Pillar.Logging");

            migrationBuilder.RenameTable(
                name: "Log",
                newName: "Log",
                newSchema: "Pillar.Logging");

            migrationBuilder.AlterColumn<string>(
                name: "Message",
                schema: "Pillar.Logging",
                table: "Log",
                type: "nvarchar(256)",
                maxLength: 256,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<string>(
                name: "Description",
                schema: "Pillar.Logging",
                table: "Log",
                type: "nvarchar(128)",
                maxLength: 128,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.CreateIndex(
                name: "DateCreated_AppId_PillarId",
                schema: "Pillar.Logging",
                table: "Log",
                columns: new[] { "DateCreated", "ApplicationId", "PillarId" });

            migrationBuilder.CreateIndex(
                name: "DateCreated_SiteId_UserId",
                schema: "Pillar.Logging",
                table: "Log",
                columns: new[] { "DateCreated", "ApplicationId", "PillarId" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "DateCreated_AppId_PillarId",
                schema: "Pillar.Logging",
                table: "Log");

            migrationBuilder.DropIndex(
                name: "DateCreated_SiteId_UserId",
                schema: "Pillar.Logging",
                table: "Log");

            migrationBuilder.RenameTable(
                name: "Log",
                schema: "Pillar.Logging",
                newName: "Log");

            migrationBuilder.AlterColumn<string>(
                name: "Message",
                table: "Log",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(256)",
                oldMaxLength: 256);

            migrationBuilder.AlterColumn<string>(
                name: "Description",
                table: "Log",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(128)",
                oldMaxLength: 128);
        }
    }
}
