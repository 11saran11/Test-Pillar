﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Pillar.Logging.Migrations
{
    public partial class LogTypeMap : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "StackTrace",
                schema: "Pillar.Logging",
                table: "Log",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<string>(
                name: "Message",
                schema: "Pillar.Logging",
                table: "Log",
                type: "nvarchar(256)",
                maxLength: 256,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(256)",
                oldMaxLength: 256);

            migrationBuilder.CreateTable(
                name: "LogTypeMap",
                schema: "Pillar.Logging",
                columns: table => new
                {
                    LogtypeId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(128)", maxLength: 128, nullable: false),
                    Description = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    DateCreated = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LogTypeMap", x => x.LogtypeId);
                });

            migrationBuilder.InsertData(
                schema: "Pillar.Logging",
                table: "LogTypeMap",
                columns: new[] { "LogtypeId", "DateCreated", "Description", "Name" },
                values: new object[,]
                {
                    { 1, new DateTime(2022, 9, 14, 6, 39, 0, 140, DateTimeKind.Utc).AddTicks(4953), null, "StatusTest" },
                    { 2, new DateTime(2022, 9, 14, 6, 39, 0, 140, DateTimeKind.Utc).AddTicks(4961), null, "Information" },
                    { 3, new DateTime(2022, 9, 14, 6, 39, 0, 140, DateTimeKind.Utc).AddTicks(4965), null, "Warning" },
                    { 4, new DateTime(2022, 9, 14, 6, 39, 0, 140, DateTimeKind.Utc).AddTicks(4968), null, "Security" },
                    { 5, new DateTime(2022, 9, 14, 6, 39, 0, 140, DateTimeKind.Utc).AddTicks(4972), null, "Exception" },
                    { 6, new DateTime(2022, 9, 14, 6, 39, 0, 140, DateTimeKind.Utc).AddTicks(4977), null, "Fatal" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Log_LogType",
                schema: "Pillar.Logging",
                table: "Log",
                column: "LogType");

            migrationBuilder.AddForeignKey(
                name: "FK_Log_LogTypeMap_LogType",
                schema: "Pillar.Logging",
                table: "Log",
                column: "LogType",
                principalSchema: "Pillar.Logging",
                principalTable: "LogTypeMap",
                principalColumn: "LogtypeId",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Log_LogTypeMap_LogType",
                schema: "Pillar.Logging",
                table: "Log");

            migrationBuilder.DropTable(
                name: "LogTypeMap",
                schema: "Pillar.Logging");

            migrationBuilder.DropIndex(
                name: "IX_Log_LogType",
                schema: "Pillar.Logging",
                table: "Log");

            migrationBuilder.AlterColumn<string>(
                name: "StackTrace",
                schema: "Pillar.Logging",
                table: "Log",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Message",
                schema: "Pillar.Logging",
                table: "Log",
                type: "nvarchar(256)",
                maxLength: 256,
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(256)",
                oldMaxLength: 256,
                oldNullable: true);
        }
    }
}
