﻿using Microsoft.EntityFrameworkCore;
using Pillar.Core;
using Pillar.Logging;
using System;

namespace Pillar.Logging
{
    public class LoggingProvider
    {
        /// <summary>
        /// Get the log from Db using LogId 
        /// </summary>
        /// <param name="LogId"></param>
        /// <returns>Log data or null</returns>
        public static Log GetlogByLogId(long LogId)
        {
            try
            {
                using (var dbContext = new LoggingContext())
                {
                    return dbContext.Log.Find(LogId);
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        /// <summary>
        /// Get the logs from Db against to application Id, pillar Id and date created 
        /// </summary>
        /// <param name="DateCreated"></param>
        /// <param name="ApplicationId"></param>
        /// <param name="PillarId"></param>
        /// <returns>List of logs or empty list</returns>
        public static List<Log> GetLogs_By_DateCreated_ApplicationId_PillarId(DateTime DateCreated, Application ApplicationId, PillarType PillarId)
        {
            try
            {
                using (var dbContext = new LoggingContext())
                {
                    return dbContext.Log.Where(x => x.DateCreated.Date == DateCreated.Date && x.ApplicationId == (int)ApplicationId && x.PillarId == (int)PillarId).ToList();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        /// <summary>
        /// Get the logs from Db against to site Id, user Id and date created 
        /// </summary>
        /// <param name="DateCreated"></param>
        /// <param name="SiteId"></param>
        /// <param name="UserId"></param>
        /// <returns>List of logs or empty list</returns>
        public static List<Log> GetLogs_By_DateCreated_SiteId_UserId(DateTime DateCreated, long SiteId, long UserId)
        {
            try
            {
                using (var dbContext = new LoggingContext())
                {
                    return dbContext.Log.Where(x => x.DateCreated.Date == DateCreated.Date && x.SiteId == SiteId && x.UserId == UserId).ToList();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        /// <summary>
        /// Search for log records depending on criteria, initially just get top 100?
        /// </summary>
        /// <returns>List of logs or empty list</returns>
        public static List<Log> GetLogs_Top_100(
            Systems selectedSystemSingle, 
            Application selectedApplicationSingle, 
            List<LogType> selectedLogTypeMultiple, 
            PillarType selectedPillarTypeSingle, 
            List<int> selectedSiteMultiple, 
            DateTime fromDate, 
            DateTime toDate)
        {
            try
            {
                using (var dbContext = new LoggingContext())
                {
                    //var a = dbContext.Log.Where(l => l.SystemId == (int)selectedSystemSingle && l.ApplicationId == (int)selectedApplicationSingle && (selectedLogTypeMultiple.Contains((LogType)l.LogType) || (int)selectedLogTypeMultiple.FirstOrDefault() == 7) && (l.PillarId == (int)selectedPillarTypeSingle || (int)selectedPillarTypeSingle == 5) && l.DateCreated >= fromDate && l.DateCreated <= toDate).Take(100).ToList();
                    //var b = dbContext.Log.Where(l => l.SystemId == (int)selectedSystemSingle && l.ApplicationId == (int)selectedApplicationSingle && (selectedLogTypeMultiple.Contains((LogType)l.LogType) || (int)selectedLogTypeMultiple.FirstOrDefault() == 7) && (l.PillarId == (int)selectedPillarTypeSingle || (int)selectedPillarTypeSingle == 5)).Take(100).ToList();
                    //return dbContext.Log.Take(100).ToList();
                    return dbContext.Log.Where(l => 
                        l.SystemId == (int)selectedSystemSingle && 
                        l.ApplicationId == (int)selectedApplicationSingle && 
                        (selectedLogTypeMultiple.Contains((LogType)l.LogType) || (int)selectedLogTypeMultiple.FirstOrDefault() == 7) && 
                        (l.PillarId == (int)selectedPillarTypeSingle || (int)selectedPillarTypeSingle == 5) && 
                        (selectedSiteMultiple.Contains((int)l.SiteId) || (int)selectedSiteMultiple.FirstOrDefault() == 0) &&
                        l.DateCreated >= fromDate && l.DateCreated <= toDate)
                        .Take(100).ToList();                 
                }
            }
            catch (Exception ex)
            {
                LoggingProvider.Log(Pillar.Core.LogType.Exception, Systems.DevReview, Pillar.Core.Application.TesselloV3, Pillar.Core.PillarType.Logging, "LoggingProvider.cs - GetLogs_Top_100()", ex.Message, String.Empty);
                throw new Exception(ex.ToString());
            }
        }

        /// <summary>
        /// Create the logs with given value
        /// </summary>
        /// <param name="LogType"></param>
        /// <param name="SystemId"></param>
        /// <param name="ApplicationId"></param>
        /// <param name="SiteId"></param>
        /// <param name="UserId"></param>
        /// <param name="PillarId"></param>
        /// <param name="Description"></param>
        /// <param name="Message"></param>
        /// <param name="StackTrace"></param>
        public static void Log(LogType LogType, Systems SystemId, Application ApplicationId, PillarType PillarId, string Description, string? Message = "", string StackTrace = "", long SiteId = 0, long UserId = 0)
        {
            try
            {
                using (var dbContext = new LoggingContext())
                {
                    Log _log = new Log()
                    {
                        LogType = (int)LogType,
                        SystemId = (int)SystemId,
                        ApplicationId = (int)ApplicationId,
                        SiteId = SiteId,
                        UserId = UserId,
                        PillarId = (int)PillarId,
                        Description = Description.Substring(0, 256),
                        Message = Message,
                        StackTrace = StackTrace
                    };

                    dbContext.Log.Add(_log);
                    dbContext.SaveChanges();
                }
            }
            catch (DbUpdateException e)
            {
                throw e;
            }
        }
    }
}
