import { docs_v1 } from "googleapis";

export class TextUtils
{
    static camelize(str : string) 
    {
        return str.toLowerCase().replace(/(?:^\w|[A-Z]|\b\w|\s+)/g, function(match, index) {
          if (+match === 0) return ""; // or if (/\s+/.test(match)) for white spaces
          return index === 0 ? match.toLowerCase() : match.toUpperCase();
        });
    }

    static getText( paragraph : docs_v1.Schema$Paragraph )
    {
        var ret  = "";

        if ( paragraph.elements )
        {
            paragraph.elements.forEach(element => {
                if (element.textRun && element.textRun.content && !element.textRun.suggestedDeletionIds)
                {
                    var hasLink = false;

                    // TODO: Links currently broken
                    // if (element.textRun.textStyle && element.textRun.textStyle.link && element.textRun.textStyle.link.url)
                    // {
                    //     hasLink = true;

                    //     ret += `<a `

                    //     if (element.textRun.textStyle.link.url.indexOf("http://glossary?") > -1)
                    //     {
                    //         var glossaryTerm = element.textRun.textStyle.link.url.split("?")[1];
                            
                    //         ret += `href="#" data-event="glossary" data-term="${glossaryTerm}"`;
                    //     }
                    //     else
                    //     {
                    //         ret += `href="${element.textRun.textStyle.link}"`;
                    //     }

                    //     ret += `>`;
                    // }

                    ret += element.textRun.content;

                    // NOTE: Links currently broken
                    // if (hasLink)
                    // {
                    //     ret += `</a>`;
                    // }
                }
            });
        }

        return ret.trim();
    }

    static getHtml( docElm : docs_v1.Schema$StructuralElement )
    {
        var paragraph = docElm.paragraph;

        var ret  = "";
        var openTag = "";
        var closeTag = "";
        
        if ( paragraph.elements )
        {
            if (paragraph.bullet)
            {
                openTag = "<li>";
                closeTag = "</li>";
            }
            else
            {
                openTag = "<p>";
                closeTag = "</p>";
            }

            paragraph.elements.forEach(element => {

                if (!element.textRun)
                {
                    return;
                }

                if (element.textRun.content && !element.textRun.suggestedDeletionIds)
                {
                    let openTag = ""
                    let closeTag = "";

                    // Hyper links
                    if (element.textRun.textStyle && element.textRun.textStyle.link && element.textRun.textStyle.link.url)
                    {
                        openTag = `<a target="blank" `
                        closeTag = `</a>`;

                        if (element.textRun.textStyle.link.url.indexOf("http://glossary?") > -1)
                        {
                            var glossaryTerm = element.textRun.textStyle.link.url.split("?")[1];
                            
                            openTag += `href="#" data-event="glossary" data-term="${glossaryTerm}"`;
                        }
                        else
                        {
                            openTag += `href="${element.textRun.textStyle.link.url}"`;
                        }

                        openTag += `>`;
                    }
                    
                    if (element.textRun.textStyle && element.textRun.textStyle.bold)
                    {
                        openTag += "<b>";
                        closeTag = "</b>" + closeTag;
                    }
                    
                    if (element.textRun.textStyle && element.textRun.textStyle.italic)
                    {
                        openTag += "<i>";
                        closeTag = "</i>" + closeTag;
                    }

                    if (element.textRun.textStyle && element.textRun.textStyle.underline && !element.textRun.textStyle.link)
                    {
                        openTag = "<u>";
                        closeTag = "</u>";
                    }


                    ret += openTag + element.textRun.content + closeTag;

                }
            });
        }

        return openTag + ret.trim() + closeTag;
    }

    static appendHtmlText( string : string, docElm : docs_v1.Schema$StructuralElement  )
    {
        var paragraphHtml = TextUtils.getHtml(docElm);

        var listId = docElm.paragraph?.bullet?.listId;
        if (listId)
        {
            // add opening UL tag if it doesn't exist
            listId = listId.replace('"', "_").replace('.', "_");

            let openTag = `<ul class="${listId}">`;
            if (string.indexOf(openTag) == -1)
            {
                string += openTag;
            }
            
            // As we add list closing tag for every list item, we need to remove the previous one so we remain with one.
            
            let strLen = string.length;
            if (strLen > 5 && string.slice(strLen - 5) == '</ul>')
            {
                string = string.slice(0, strLen - 5);
            }

            string += paragraphHtml + '</ul>';
        }
        else
        {
            string += paragraphHtml;
        }

        return string;
    }

    /**
     * 
     * @param table A Google doc table
     * @returns An array of objects that have keys that match the column headings with values that match each row below the heading. An HTML version of the data
     * is also stored at keyName+'Html' e.g. optionTextHtml
     */
    static tableToArray( table : docs_v1.Schema$Table )
    {
        var ret : Array<any> = [];

        if (!table.tableRows) return ret;

        for (var i = 1; i < table.tableRows.length; i ++)
        {
            var currentRow = table.tableRows[i];
            if (!currentRow.tableCells) continue;

            var rowObj : any = {};

            for (var j = 1; j < currentRow.tableCells.length; j++)
            {
                var currentCel = currentRow.tableCells[j];

                var destination = rowObj;
                var keys =  TextUtils.getText(table.tableRows[0].tableCells![j].content![0].paragraph!).split("_");
                for (var k = 0; k < keys.length; k++)
                {
                    var data = TextUtils.getText(currentCel.content![0].paragraph!);
                    var html = TextUtils.getHtml(currentCel.content![0]);

                    var key = keys[k];
                    if (key.indexOf(" ") > -1)
                    {
                        key = TextUtils.camelize( keys[k] );
                    }
                    
                    if (key && data)
                    {
                        key = key[0].toLowerCase() + key.slice(1);

                        var isLastKey = (k == keys.length -1);
                        if (isLastKey)
                        {
                            destination[key] = isNaN(+data)? data : +data;
                            destination[key + 'Html'] = html;
                        }
                        else
                        {
                            // Make another object one level in and set that object as the destination
                            if (!destination[key])
                            {
                                destination[key] = {};
                            }
                            
                            destination = destination[key];
                        }
                    }
                }
            }

            ret.push( rowObj );
        }

        return ret;
    }
}
