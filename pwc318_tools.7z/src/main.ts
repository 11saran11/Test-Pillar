import { docs_v1, oauth2_v1, oauth2_v2, google } from 'googleapis';
import { AuthPlus, GoogleApis } from 'googleapis/build/src/googleapis';
import { OAuth2Client, OAuth2ClientOptions, Credentials } from 'google-auth-library';
import readline from 'readline';
import fs from 'fs';
import { prependOnceListener } from 'cluster';
import { DataKeyMap, DataKeys } from './dataMap';
import { TextUtils } from './textUtils';
import { CourseModel } from './courseModel/course';
import { BaseDataObject } from './courseModel/baseDataObject';
import { createServer, IncomingMessage, ServerResponse } from 'http';
import { parse } from 'url';

interface CourseDef {
    ancilleryDocID: string;
    topicDocIDs: string[];
}

class Main {
    private readonly SCOPE = "https://www.googleapis.com/auth/documents.readonly";
    private readonly TOKEN_PATH = "./data/token.json";
    private readonly CLIENT_SECRET_PATH = "./data/client_secret.json";
    private readonly COURSE_DATA_OUTPUT_FOLDER = "./data/topics/";
    private readonly DATA_FILE_NAME = "course_model.json";
    private readonly COURSE_DEF_PATH = "./data/course_def.json";

    private _client: OAuth2Client;

    private _clientSecretJson: any;
    private _port: number = 5000;

    // private readonly _docID : string = "16EVwRjsQKw_2oiyTqD3TbZwsCq9x4n3AAWpKwSi2E-w";

    // "1gmtDY4xlUIclrC0wEmNEBgWIbqxvv45kV6GFQNNHutU"
    private _courseDef: CourseDef;

    constructor() {
        console.log("Course document converter");

        const courseDefRaw = fs.readFileSync(this.COURSE_DEF_PATH, {
            encoding: 'utf8'
        });
        this._courseDef = JSON.parse(courseDefRaw);

        // Configure the gapi.auth2 and gapi.client objects
        const clientSecretRaw = fs.readFileSync(this.CLIENT_SECRET_PATH, {
            encoding: 'utf8'
        });

        this._clientSecretJson = JSON.parse(clientSecretRaw);

        this._client = new OAuth2Client({
            clientId: this._clientSecretJson.web.client_id,
            clientSecret: this._clientSecretJson.web.client_secret,
            redirectUri: this._clientSecretJson.web.redirect_uris[0]
        });

        this.run();
    }

    private async startServer() {
        const server = createServer(async (request: IncomingMessage, response: ServerResponse) => {
            if (request.url.startsWith('/oauth2callback')) {
                let q: any = parse(request.url, true).query;

                if (q.error) {
                    console.log('oauth2callback - Error:' + q.error);
                } else {
                    const coded = decodeURIComponent(q.code);
                    console.log('decoded auth code', coded);

                    // Get access and refresh tokens (if access_type is offline)
                    let { tokens } = await this._client.getToken(coded);
                    // this._client.setCredentials(tokens);
                    console.log('oauth2callback - token', tokens)

                }
            }
        });

        server.listen(this._port, () => {
            console.log(`Server listening on port ${this._port}`);
        });
    }

    private async run() {
        try {
            this.startServer();
            await this.authenticate();
        }
        catch (e) {
            console.error(e);
            console.error("Failed to authenticate");

            process.exit(1);
        }

        if (!fs.existsSync(this.COURSE_DATA_OUTPUT_FOLDER)) {
            fs.mkdirSync(this.COURSE_DATA_OUTPUT_FOLDER);
        }

        await this.processCourse(this._courseDef);
    }

    private async processCourse(courseDef: CourseDef) {
        var courseModel: CourseModel = new CourseModel();

        for (var i = 0; i < courseDef.topicDocIDs.length; i++) {
            let docID = courseDef.topicDocIDs[i];

            var doc = await this.getDocument(docID);
            if (doc) {
                console.log(`Processing docID: ${docID} `);
                this.convertToObject(courseModel, doc);
            }
            else {
                console.error("No document found with ID: ", docID);
            }
        }

        var courseFolder = this.COURSE_DATA_OUTPUT_FOLDER + "/";
        if (!fs.existsSync(courseFolder)) {
            fs.mkdirSync(courseFolder);
        }

        var rawData = courseModel.toRawData();
        var jsonOutput = JSON.stringify(rawData)

        fs.writeFile(courseFolder + this.DATA_FILE_NAME, jsonOutput, (err) => {
            if (err) return console.error(err);
        });
    }

    private convertToObject(courseModel: CourseModel, doc: docs_v1.Schema$Body) {
        var objectRef: BaseDataObject = courseModel; // Reference changes depending on the current hierachical depth
        var objectKey: any = "";

        doc.content!.forEach(element => {

            if (element.paragraph && element.paragraph.paragraphStyle && element.paragraph.paragraphStyle.namedStyleType) {
                var unmappedKey = element.paragraph.paragraphStyle.namedStyleType;
                var dataKey = DataKeyMap.map[unmappedKey] || unmappedKey; // Either a mapped key or HEADING_X
                var dataValue = TextUtils.getText(element.paragraph);

                if (dataKey == DataKeys.propertyHeading) {
                    dataKey = TextUtils.camelize(TextUtils.getText(element.paragraph));
                }
                else if (dataKey == DataKeys.dataVal) {
                    // Put this in the current object ref
                    if (objectKey) {
                        objectRef.setData(objectKey, dataValue, element);
                    }

                    return;
                }

                objectKey = dataKey;
                objectRef = objectRef.processKey(objectKey, dataValue);
            }
            else if (element.table && objectKey) {
                objectRef.setData(objectKey, dataValue, element);
            }

        });

        return courseModel;
    }

    private async authenticate() {
        console.log("Attempting to load token");

        try {
            var tokensJson = fs.readFileSync(this.TOKEN_PATH, {
                encoding: 'utf8'
            });

            var tokens: Credentials = JSON.parse(tokensJson);

            console.log("Loaded and parsed tokens");
        }
        catch (e) {
            console.log("Token failed to load. Follow the link below and paste the authenication code into the terminal\n");

            var authUrl = await this._client.generateAuthUrl({
                scope: [
                    this.SCOPE
                ],
                redirect_uri: this._clientSecretJson.web.redirect_uris[0]
            });

            console.log(authUrl);

            const rl = readline.createInterface({
                input: process.stdin,
                output: process.stdout,
            });

            var code: string = await new Promise((resolve) => {
                rl.question("Paste auth code here: ", (code: string) => {
                    rl.close();
                    resolve(code);
                });
            });

            var token = await this._client.getToken(code);
            var tokens = token.tokens;

            fs.writeFile(this.TOKEN_PATH, JSON.stringify(tokens), (err) => {
                if (err) return console.error(err);
                console.log('Token stored at: ', this.TOKEN_PATH);
            });
        }

        this._client.setCredentials(tokens);
    }

    private async getDocument(docId: string) {
        var googleDocs = google.docs({
            version: "v1",
            auth: this._client,
        });

        var doc = await googleDocs.documents.get({
            documentId: docId
        });

        return doc.data.body;
    }

}
new Main();