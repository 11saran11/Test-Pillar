import { docs_v1 } from "googleapis";
import { TextUtils } from "../textUtils";
import { Screen } from "./screen";

export class MCQ extends Screen
{
    public options : MCQOption[] = [];
    public commonFeedback : string = "";

    public setData( key : string, value : any, docElm : docs_v1.Schema$StructuralElement)
    {
        key = key.replace(/[0-9]/g, ""); // Remove number such as Reveal 1, Reveal 2
        key = key.replace(/\(.*/g, ""); // Remove extra text within parenthesees e.g. SCREEN TITLE (10 WORDS MAX)
        key = key.trim();

        if (key == "answerOptions" && docElm.table)
        {
            this.options = TextUtils.tableToArray(docElm.table).map( elm => {
                return new MCQOption(elm);
            });
        }
        else if (key == "feedbackGenericText")
        {
            this.commonFeedback = TextUtils.appendHtmlText(this.commonFeedback, docElm);
        }

        super.setData( key, value, docElm);
    }
}

export class MCQOption
{
    public isCorrect : Boolean;
    public text : string; 

    constructor( data : {answerOptionHtml : string, answerCorrectTag : string})
    {
        this.isCorrect = data.answerCorrectTag.toLowerCase() == "true";
        this.text = data.answerOptionHtml;
    }
}