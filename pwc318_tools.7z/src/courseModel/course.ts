import { DataKeys } from "../dataMap";
import { TextUtils } from "../textUtils";
import { BaseDataObject } from "./baseDataObject";
import { Topic } from "./topic";

export class CourseModel extends BaseDataObject
{
    public static COURSE_ID = "pwc542";

    public topics : Topic[] = [];

    public processKey( key : string, value : string ) 
    {
        if (key == DataKeys.topic)
        {
            let topicId = TextUtils.camelize(value);
            let topic : Topic = this.topics.find( t => t.topicId == topicId);
            if (topic)
            {
                topic.reset();
            }
            else
            {
                topic = new Topic(this);
                topic.topicId = topicId;
                this.topics.push(topic);
            }

            return topic;
        }

        return this;
    }

    public getParent()
    {
        return null;
    }
}