import { docs_v1 } from "googleapis";
import { DataKeys } from "../dataMap";
import { TextUtils } from "../textUtils";
import { BaseDataObject } from "./baseDataObject";
import { CourseModel } from "./course";

export class Screen extends BaseDataObject
{
    public screenId : string = "";
    public screenType : string = ""; // e.g. textGraphicScreenTopDesktop
    public learningObjective : string = "";


    public learnContent : LearnContent = new LearnContent();

    private _currentSection? : Section;

    constructor(parent? : BaseDataObject)
    {
        super(parent);

        this._propertyIgnoreList.push('_currentSection');
    }

    public setData( key : string, value : any, docElm : docs_v1.Schema$StructuralElement)
    {
        if (!value || (typeof value == 'string' && !value.trim()))
        {
            return;
        }

        key = key.replace(/[0-9]/g, ""); // Remove number such as Reveal 1, Reveal 2
        key = key.replace(/\(.*/g, ""); // Remove extra text within parenthesees e.g. SCREEN TITLE (10 WORDS MAX)
        key = key.trim();

        // PWC318 hacks
        // if (key.indexOf('learningObjective') > -1)
        // {
        //     key = 'learningObjective';
        // }

        // Screen type is taken from heading 3 instead of the data heading
        if (key.indexOf('screenType') > -1)
        {
            return;
        }

        //-- End of PWC318 hacks --//

        if ((<any>this)[key] != undefined)
        {
            (<any>this)[key] = value;
            return;
        }

        // Mappings
        switch (key)
        {
            case "screenTitle" : this.learnContent.title += value; break;
            case "text" : {
                if (this._currentSection)
                {


                    this._currentSection.body = TextUtils.appendHtmlText(this.learnContent.body, docElm);
                }
                else
                {
                    this.learnContent.body = TextUtils.appendHtmlText(this.learnContent.body, docElm);
                }
                
                break;
            }

            case "introText" : 
                this.learnContent.body = TextUtils.appendHtmlText(this.learnContent.body, docElm);
                break;

            case "sectionTitle":
            case "cardFront":
            case "revealButtonText":
            case "revealTitle" :
                if (this._currentSection)
                {
                    this._currentSection.title += value;
                }
                break;

            case "cardBack" :
            case "sectionText" :
            case "revealText" :
                if (this._currentSection)
                {
                    this._currentSection.body = TextUtils.appendHtmlText(this._currentSection.body, docElm);
                }
                break;
            case "videoTranscript" :
                if (this._currentSection)
                {
                    this._currentSection.body = TextUtils.appendHtmlText(this._currentSection.body, docElm);
                }
                this.learnContent.video = `[ASSETS_DIR]/video/${CourseModel.COURSE_ID}_${this.screenId}.mp4`;
                this.learnContent.captions = `[ASSETS_DIR]/video/${CourseModel.COURSE_ID}_${this.screenId}.vtt`; 
                this.learnContent.contentGraphic = `[ASSETS_DIR]/video/${CourseModel.COURSE_ID}_${this.screenId}.jpg`; 
                break;

            case "prompt" : this.learnContent.prompt += value; break;
        }

    }

    public processKey(key : string, value : string)
    {
        if (key.indexOf('learningObjective') > -1)
        {
            this.learningObjective = key;
            return this;
        }

        key = key.replace(/[0-9]/g, ""); // Remove number such as Reveal 1, Reveal 2
        key = key.replace(/\(.*/g, ""); // Remove extra text within parenthesees e.g. SCREEN TITLE (10 WORDS MAX)
        key = key.trim();

        switch (key)
        {
            case "graphic" : 
                // [ASSETS_DIR]/content_images/_desktop/pwc016_101_100.svg 
                this.learnContent.contentGraphic = `[ASSETS_DIR]/content_images/_desktop/${CourseModel.COURSE_ID}_${this.screenId}.svg`;
                this.learnContent.contentGraphicPhone = `[ASSETS_DIR]/content_images/_phone/${CourseModel.COURSE_ID}_${this.screenId}.svg`; 
                return this;
                
            case "card" :
            case "section" :
            case "reveal" : 
            case "videoTranscript" : 
                this._currentSection = new Section();
                this._currentSection.group = "0";
                this.learnContent.sections.push( this._currentSection);
                return this;

            // case "text" : 
            //     this._currentSection = new Section();
            //     this._currentSection.group = "1";
            //     this.learnContent.sections.push( this._currentSection);
            //     return this
                
            case "revealButtonGraphic" :
                if (this._currentSection)
                {
                    // [ASSETS_DIR]/content_images/pwc016_101_110_1.svg
                    this._currentSection.icon = `[ASSETS_DIR]/content_images/${CourseModel.COURSE_ID}_${this.screenId}_${this.learnContent.sections.length}.svg`;
                }
                return this;

            case DataKeys.screen : 
                return this.parent.processKey(key, value);

            case DataKeys.topic : 
                return this.parent.processKey(key, value);
            
        }

        // Nothing special to do with this key

        return this;
    }

}

export class LearnContent
{
    public title : string = "";
    public body : string = "";
    public prompt : string = "";
    public contentGraphic : string = "";
    public contentGraphicPhone : string = "";
    public sections : Section[] = [];
    
    public captions : string;
    public video : string;

}

export class Section
{
    public group : string = "";
    public title : string = "";
    public icon : string = "";
    public body : string = "";
}