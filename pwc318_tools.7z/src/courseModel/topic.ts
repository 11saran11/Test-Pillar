import { docs_v1 } from "googleapis";
import { DataKeys } from "../dataMap";
import { TextUtils } from "../textUtils";
import { BaseDataObject } from "./baseDataObject";
import { MCQ } from "./mcq";
import { Screen } from "./screen";

export class Topic extends BaseDataObject
{
    public topicId : string = "";
    public title : string = "";
    public screens : Screen[] = [];
    public assessmentPools : AssessmentPool[] = [];

    private _currentPool : AssessmentPool;

    constructor(parent : BaseDataObject)
    {
        super(parent);
        this._propertyIgnoreList.push('_currentPool');
    }

    public reset()
    {
        this._currentPool = undefined;
    }

    public setData( key : string, value : any, docElm : docs_v1.Schema$StructuralElement)
    {
        if ((<any>this)[key] != undefined)
        {
            (<any>this)[key] = value;
        }

        // Mappings
        switch (key)
        {
            case "topicTitle" : this.title = value;
        }
    }

    public processKey( key : string, value : string ) 
    {
        if ( key == DataKeys.screen)
        {
            var screenInfo = value.replace('-', '–').split('–').map( elm => elm.trim());

            var screenId = screenInfo[0];
            var screenType = this.getScreenType( screenInfo[1] )
            
            if (screenType)
            {
                // TODO: Make this scalable
                var screen : Screen;
                if (screenType == 'mcq')
                {
                    screen = new MCQ(this);
                }
                else
                {
                    screen = new Screen(this);
                }

                screen.screenId = screenId;
                screen.screenType = screenType;

                // PWC318 Specific
                if (this._currentPool)
                {
                    this._currentPool.screens.push(screen);
                }
                else
                {
                    this.screens.push(screen);
                }

                return screen;
            }
            else
            {
                console.log(`No screen type defined for screenId: ` + screenId)
            }
        }
        else if (key == DataKeys.topic)
        {
            this._currentPool = new AssessmentPool();
            this.assessmentPools.push(this._currentPool);

            return this;
        }

        // Nothing special to do with this key
        return this;
    };

    private getScreenType(screenType? : string)
    {
        if (!screenType)
        {
            return "textAndGraphic";
        }

        screenType = screenType.toLocaleLowerCase().trim();

        switch(screenType)
        {
            case "text and graphic (left)" : return "textGraphicScreenSideLeft";
            case "text and graphic (right)" : return "textGraphicScreenSideRight";
            case "text and graphic (top)" : return "textGraphicScreenTopDesktop";
            case "text and graphic (bottom)" : return "textGraphicScreen";
            case "text and graphic" : return "textGraphicScreen";
            case "icon reveal" : return "iconRevealScreen";
            case "columns" : return "textColumnScreen";
            case "accordion" : return "titleRevealScreen";
            case "animation" : return "videoScreen";
            case "test out question" : return "questionView";
            case "text only" : return "textOnlyScreen";
            case "text" : return "textOnlyScreen";
            case "text card reveal" : return "cardRevealScreen";
            case "video" : return "videoScreen";
        }

        console.log(`No mapping for screen type: ${screenType}`);

        return TextUtils.camelize(screenType);
    }
}

export class AssessmentPool
{
    public screens : Screen[] = [];
}