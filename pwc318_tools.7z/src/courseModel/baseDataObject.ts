import { docs_v1 } from "googleapis";

export class BaseDataObject
{
    protected _parent? : BaseDataObject;
    protected _propertyIgnoreList = ['_propertyIgnoreList', '_parent', 'parent'];

    constructor(parent? : BaseDataObject)
    {
        this._parent = parent;
    }

    public setData( key : string, value : string, docElm : docs_v1.Schema$StructuralElement)
    {
        if ((<any>this)[key] != undefined)
        {
            (<any>this)[key] = value;
        }
    }

    public processKey( key : string, value : string ) : BaseDataObject
    {
        return this;
    }

    public toRawData()
    {
        return BaseDataObject.sanitiseObj(this, this._propertyIgnoreList);
    }

    public static sanitiseObj(dirtyObj : any, propertyIgnoreList? : string[])
    {
        var cleanObj : any = {};

        for (var key in dirtyObj)
        {
            if (propertyIgnoreList && propertyIgnoreList.indexOf(key) > -1)
            {
                continue;
            }

            var dirtyProperty = dirtyObj[key];

            var cleanProperty = BaseDataObject.sanitiseObjProperty(dirtyProperty);
            if (cleanProperty != undefined)
            {
                cleanObj[key] = cleanProperty;
            }
        }

        return cleanObj;
    }

    public static sanitiseObjProperty(obj : any)
    {
        if (typeof obj == 'string' || typeof obj == 'number' || typeof obj == 'boolean')
        {
            return obj;
        }
        else if (obj instanceof BaseDataObject)
        {
            return obj.toRawData();
        }
        else if (Array.isArray(obj))
        {
            return obj.map( BaseDataObject.sanitiseObjProperty )
        }
        else if (typeof obj == 'object')
        {
            return BaseDataObject.sanitiseObj(obj);
        }

        // Discard property as it's not fit for JSON
        return null; 
    }

    // GET / SET

    public get parent()
    {
        return this._parent;
    }

}