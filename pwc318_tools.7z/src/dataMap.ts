export enum DataKeys 
{
    meta = "meta",
    topic = "topic",
    screen = "screen",
    propertyHeading = "propertyHeading",
    dataVal = "dataVal"
}

export class DataKeyMap
{
    static map : { [key:string] : string } = {
        NORMAL_TEXT : DataKeys.dataVal,
        HEADING_1 : DataKeys.meta,
        HEADING_2 : DataKeys.topic,
        HEADING_3 : DataKeys.screen,
        HEADING_4 : DataKeys.propertyHeading,
        HEADING_5 : DataKeys.propertyHeading, // Sub heads of sections 
    }
}