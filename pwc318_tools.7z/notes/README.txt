RUNNING THE SCRIPT TOOL

- Check out pwc318 tools
- npm install
- npx tsc
- node .\build\main.js
- Follow the google link in the conosole to authenticate the tool with your google account. I'll say the app is dangerous because there is no certificate but just trust it. You'll be asked to paste a code back into the terminal
- The tool should run and the extracted data should be in:
                data\topics\course_model.json

UPDATING THE PROJECT AND RECOMPILING

- check out pwc318
- copy course_model.json over the one found in the project: src\projects\pwc318\data\model\course_model.json
- To make a final release just run: 
                src\projects\pwc318\_build\build_client_final.bat
- If they need a version with BIT for some reason then you can run:
                src\projects\pwc318\_build\build_client_release.bat
