const predefinedAttributes = {
        isComponent: 'isComponent',
        isIgnored: 'isIgnored',
        tag: 'tag',
        style: 'style',
        attributeName: 'attributeName',
        attributeValue: 'attributeValue'

}

export default predefinedAttributes;
