// This is code of word to xml script importing tool
// Import Statement
import { readFile, writeFile } from 'fs';
import { JSDOM } from 'jsdom';
import predefinedAttributes from './componentName.js';
import DomParser from 'dom-parser';
import { DOMImplementation, XMLSerializer } from 'xmldom';
import xmlFormat from 'xml-formatter';

let courseConfigObject = {
    courseConfig: []
}
const domImplementation = new DOMImplementation();
const xmlDoc = domImplementation.createDocument(null, 'comp', null);

function createConfigObject(configXMLData) {
    let parser = new DomParser();
    let parsedXML = parser.parseFromString(configXMLData);
    let tagArray = parsedXML.getElementsByTagName('importstyle');
    tagArray.forEach((node) => {
        if (node.getAttribute(predefinedAttributes.isComponent) === 'true' && node.getAttribute(predefinedAttributes.isIgnored) === 'false') {
            let parentObject = {
                componentTag: node.getAttribute(predefinedAttributes.tag),
                isComponent: node.getAttribute(predefinedAttributes.isComponent) === 'true' ? true : false,
                isIgnored: node.getAttribute(predefinedAttributes.isIgnored) === 'true' ? true : false,
                attribute: [],
                child: [],
                style: []
            }
            node.childNodes.forEach((childNode) => {
                if (childNode && childNode.getAttribute(predefinedAttributes.isComponent) === 'true' && childNode.getAttribute(predefinedAttributes.isIgnored) === 'false') {
                    {
                        parentObject.child.push(childNode.getAttribute(predefinedAttributes.tag))
                    }

                } else if (childNode && childNode.getAttribute(predefinedAttributes.isComponent) === 'false' && childNode.getAttribute(predefinedAttributes.isIgnored) === 'false') {
                    parentObject.attribute.push(childNode.getAttribute(predefinedAttributes.attributeName));
                    parentObject.style.push(childNode.getAttribute(predefinedAttributes.style))
                }
            })

            courseConfigObject.courseConfig.push(parentObject);
        }
    });
    return courseConfigObject;
}

let fileName = './config.xml';
readFile(fileName, 'utf-8', function (err, htmlCode) {
    if (err) console.log(err);
    let scriptObject = JSON.stringify(createConfigObject(htmlCode), null, 4);
    writeFile('./config.json', scriptObject, (error) => {
        if (error) throw new Error(error)
        console.log("Config file generated Successfully");
    })
    createScriptXML(scriptObject);
});

function createScriptXML(configObject) {
    const configObjectArray = JSON.parse(configObject);

    readFile('./wordHTML.html', 'utf-8', (error, htmlCode) => {
        if (error) throw new Error(error);
        const parsedHtml = new JSDOM(htmlCode).window.document;

        configObjectArray.courseConfig.forEach((obj, index) => {
            const childElm = xmlDoc.createElement(obj.componentTag);
            configObjectArray.courseConfig[index].attribute.forEach((attribute, attributeindex) => {
                const sourceElm = parsedHtml.querySelector(`.${configObjectArray.courseConfig[index].style[attributeindex]}`);
                if (sourceElm) {
                    const attrValue = sourceElm.textContent.replace(/\s+/g, ' ').replace(/\n/g, '').trim();
                    childElm.setAttribute(attribute, attrValue);
                }
            });
            appendChildrenToXml(configObjectArray, childElm, obj.componentTag)
        });

        const xmlString = new XMLSerializer().serializeToString(xmlDoc);
        writeFile('./script.xml', xmlFormat(xmlString), (error) => {
            if (error) throw new Error(error)
            console.log("File Generated Successfully");
        })


    });
}

function appendChildrenToXml(configObjectArray, childElement, tagName) {
    let isAppended = false;
    if (childElement && tagName) {
        for (let configs of configObjectArray.courseConfig) {
            if (configs.child && configs.child.length > 0) {
                const index = configs.child.indexOf(tagName);
                if (index !== -1) {
                    const parentElm = xmlDoc.documentElement.getElementsByTagName(`${configs.componentTag}`);
                    if (parentElm.length > 0) {
                        parentElm[0].appendChild(childElement);
                        isAppended = true;
                        break;
                    } else {
                        xmlDoc.documentElement.appendChild(childElement);
                        isAppended = true;
                        break;
                    }
                }
            };
        }

        if (!isAppended) {
            xmlDoc.documentElement.appendChild(childElement);
        }
    }
}
